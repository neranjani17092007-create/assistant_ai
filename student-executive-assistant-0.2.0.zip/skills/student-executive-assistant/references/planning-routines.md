# Planning routines

## Daily brief: "Plan my day" or "What needs my attention?"

Read Study Companion assignments (all), list calendars, and retrieve today's events and the next seven days from relevant owned calendars. Include all-day and ongoing events. Page bounded searches; report skipped calendars or partial results. Avoid treating empty calendar space as confirmed personal availability when class schedules are missing.

Search Gmail over a bounded recent window (initially 14 days) for deadlines, assignments, project messages, interviews, internships and hackathons. Read candidate messages before treating them as actionable. Distinguish registered commitments, invitations needing an answer, and marketing suggestions. The unread label alone does not imply importance. Cite the source message or event beside each action.

Return: up to three priorities with concrete next actions; today's fixed commitments in local time; approaching deadlines and conflicts; replies needed; and one feasible suggested focus block if useful. Flag uncertain cutoff times rather than inventing them. Suggestions are unsaved until a calendar write succeeds. Expand the search when the user requests broader coverage.

## Projects, hackathons and internships

Turn the user's goal into a small milestone plan with a next action, known deadline, effort estimate explicitly marked as estimated, and blocker. Protect existing academic commitments and allow meals, rest and transition time. When workload exceeds available time, identify a tradeoff and ask which commitment can move; do not silently remove it.

For opportunities, verify the official source when a deadline, eligibility, fee or requirement is uncertain. Separate registration deadlines from submission deadlines and normalize explicit timezones. Never infer application status from marketing email. Prepare a concise submission checklist and draft project descriptions or cover letters when requested. Do not apply, register, pay or upload private documents without explicit user authorization.

## Replies and people

Use Google Contacts only to resolve a relevant person; do not bulk-export contacts. Ask if multiple people match and the recipient matters. Draft useful replies in chat by default; create a Gmail draft when asked. Verify names, dates, recipient and commitments from source context. Send or forward only with explicit human authorization for that message. Automated checks surface reply needs without sending, marking read, archiving or relabeling mail.

## Weekly review: "Plan my week"

Review the next 14 days of calendar commitments and current work. Group academics, projects, hackathons/internships and personal commitments. Show overloaded days and a realistic next-week plan. Leave breathing room. Carry incomplete work forward as a suggestion, preserving existing records and submission states.

## Automation and continuity

Use supported recurring automation tools; inspect existing local schedules before creating a duplicate. Keep the earlier assignment-sync automation separate from email and schedule triage. Do not claim a historical schedule remains active without reading its current state. Reuse a matching planning automation when found.

For background planning checks, read relevant sources, compare against the previous successful check and stay quiet if nothing meaningful changed. Notify for a new actionable deadline, material change, conflict, interview, or required reply. Include source links, local times and next actions; disclose failures once rather than silently implying complete coverage. Scheduled runs must not send messages, create calendar entries, overwrite research packs, or modify assignments unless separately authorized. Preserve a last-successful-check summary in the automation's supported continuity context; never fabricate state.

For a device switch, provide a short handoff with timezone, current priorities, next deadlines, relevant source links and pending decisions. Use the same connected account on supported clients; reconnect services where needed. Never package passwords, tokens, mailbox contents or private contacts. When offline or tools are unavailable, provide a clearly labeled plan from supplied context and identify what needs rechecking.

